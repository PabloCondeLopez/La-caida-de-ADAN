package com.lcda.CaidaDeAdanLobby;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaidaDeAdanLobbyApplicationTests {

	@Test
	void contextLoads() {
	}

}
